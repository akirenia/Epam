package epam.labs.lab2_2.interfaces;

public interface IChildGardenChild extends IChild{

	public String getChildGardenName();
	public void setChildGardenName(String childGardenName);	
	

	public String getChildGardenAddress();
	public void setChildGardenAddress(String childGardenAddress);	

}
