package epam.labs.lab2_2.interfaces;

public interface ISchool {
	public int getSchoolNumber();
	public void setSchoolNumber(int schoolNumber);
	
	public String getSchoolName();
	public void setSchoolName(String schoolName);
	
	public String getSchoolType();
	public void setSchoolType(String schoolType);
}
