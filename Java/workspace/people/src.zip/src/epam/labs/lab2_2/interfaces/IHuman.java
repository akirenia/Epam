package epam.labs.lab2_2.interfaces;

public interface IHuman {
	public String getFirstName();
	public String getLastName();
	public String getSex();	
	public void setFirstName(String firstName);
	public void setLastName(String lastName);
	public void setSex(String sex);
}
