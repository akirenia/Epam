package epam.labs.lab2_2.interfaces;

public interface IChild {
	public String getChildType();
	public void setChildType(String childType);
}
