package epam.labs.lab2_2.interfaces;

public interface IStudent {
	public String getRecordBookNumber();
	public void setRecordBookNumber(String recordBookNumber);
	public String getStudyType();
	public void setStudyType(String studyType);
}
