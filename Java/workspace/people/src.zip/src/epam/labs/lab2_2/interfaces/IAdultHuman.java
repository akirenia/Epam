package epam.labs.lab2_2.interfaces;

public interface IAdultHuman{
	public String getIdentificationNumber();
	public void setIdentificationNumber(String identificationNumber);
}
